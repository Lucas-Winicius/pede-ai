<script setup lang="ts">

</script>

<template>
  <header>
    <h1>Pede.ai</h1>
    <p>Entregar Para <strong>Lorem ipsum dolor sit</strong></p>
    <div>
      <v-icon name="la-user-alt-solid" />
    </div>
  </header>
</template>

<style scoped></style>
