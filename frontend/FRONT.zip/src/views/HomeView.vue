<script setup lang="ts">
import HeaderComponent from '@/components/HeaderComponent.vue';

</script>

<template>
  <HeaderComponent />
  <main>
    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eius, alias? Hic maiores itaque laudantium rerum
      eveniet optio vitae alias magnam beatae sapiente, minima magni. Dolorum recusandae rem ullam beatae libero?</p>
  </main>
</template>
